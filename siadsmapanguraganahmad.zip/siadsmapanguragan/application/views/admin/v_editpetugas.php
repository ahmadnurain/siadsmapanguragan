
       <!-- Container Fluid-->
       <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?= $judul;?></h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>             
              <li class="breadcrumb-item active" aria-current="page"><?= $judul;?></li>
            </ol>
          </div>



          <div class="modal-body">
                <form action="<?php echo base_url() . 'Petugas/fungsiEdit'; ?>" method="post">
                <input class="form-control form-control-sm  mb-3"  id="id" name="id" type="hidden" value="<?php echo $queryPet->id?>">
                <input class="form-control form-control-sm  mb-3"  id="nisn" name="nisn" type="text" value="<?php echo $queryPet->nama_petugas?>">
                <input class="form-control form-control-sm  mb-3"  id="nama" name="nama" type="text" value="<?php echo $queryPet->nip_petugas?>">
                <input class="form-control form-control-sm  mb-3"  id="nama_kelas" name="nama_kelas" type="text" value="<?php echo $queryPet->jabatan?>">
                            <input class="form-control form-control-sm  mb-3" required id="tanggal_lahir" name="tanggal_lahir" type="text" value="<?php echo $queryPet->level?>">
  
               
 
             
              
                  <a href="<?= base_url('petugas');?>" class="btn btn-outline-primary" >Batal</a>
                  <button type="submit" class="btn btn-primary">Simpan</button>
          
         
            </form>

                    </div>
                    </div>
</div>










<!-- footer --> 
</div>