        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <!-- <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Pages</li>
              <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol> -->
          </div>

          <div class="text-center">
            <h1 class="pt-1" style="color:black;"><b>SELAMAT DATANG DI </b></h1>
            <h4 class="pt-1" style="color:black;">Aplikasi Administrasi Pembayaran</h4>

            <img src="<?php echo base_url(); ?>assets/img/logo/logo.jpg" style="max-height: 150px">
            <h3 class="pt-2" style="color:black;">SMA PLUS NU PANGURAGAN</h3>
          </div>

      
        </div>