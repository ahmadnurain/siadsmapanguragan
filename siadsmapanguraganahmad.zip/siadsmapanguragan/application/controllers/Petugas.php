<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Petugas extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_global_model');
        $this->load->model('Petugas_model');

    }

    public function index()
    {
        $data['title']  = 'SIAD SMA Pangurugan';
        $judul['judul'] = 'Data Petugas';
        $queryAllPet = $this->Petugas_model->ambildatapetugas();
        $DATA = array('queryPet' => $queryAllPet);
        $DATA1 = $judul + $DATA;
		$this->load->view('template/header',$data);
		$this->load->view('template/sidebar');
        $this->load->view('template/topbar');
        $this->load->view('admin/petugas',$DATA1);
        $this->load->view('template/footer');
    }

    public function editpetugas($id){
        

        $data['title']  = 'SIAD SMA Pangurugan';
        $judul['judul'] = 'Edit Data Petugas';
        
        $queryAllPet = $this->Petugas_model->getDataDetail($id);
        $DATA2 = array('queryPet' => $queryAllPet);
       
        $DATA4 = $judul  +$DATA2 ;
		$this->load->view('template/header',$data);
		$this->load->view('template/sidebar');
        $this->load->view('template/topbar');
        $this->load->view('admin/v_editpetugas',$DATA4);
        $this->load->view('template/footer');
    }

    public function tambah_aksi()
    {
		$nama_petugas = $this->input->post('nama_petugas');
        $nip_petugas = $this->input->post('nip_petugas');
        $jabatan = $this->input->post('jabatan');
        $level = $this->input->post('level');
      
        
        $data = array(
            'nama_petugas' => $nama_petugas,
            'nip_petugas' => $nip_petugas,
            'jabatan' => $jabatan,
            'level' => $level
        );

        $query = $this->Petugas_model->input_data_petugas($data);

        
        if($query > 0)
        {
            $this->M_global_model->ntf_swal('Informasi', 'Berhasil simpan data', 'success'); 
        }else{
            $this->M_global_model->ntf_swal('Informasi', 'Gagal simpan data', 'error');
		}
        redirect(base_url('petugas'));
	}
    public function fungsiEdit()
	{


        $nama_petugas = $this->input->post('nama_petugas');
        $nip_petugas = $this->input->post('nip_petugas');
        $jabatan = $this->input->post('jabatan');
        $level = $this->input->post('level');
      
        
        $data = array(
            'nama_petugas' => $nama_petugas,
            'nip_petugas' => $nip_petugas,
            'jabatan' => $jabatan,
            'level' => $level
        );

		$query = $this->Petugas_model->updateDataPetugas($id, $data);
		if($query <0){
            $this->M_global_model->ntf_swal('Informasi', 'Gagal update data', 'error');
			
		} else {
			$this->M_global_model->ntf_swal('Informasi', 'Berhasil update data', 'success');
		}
		redirect(base_url('petugas'));

	}

    public function fungsiDelete($id)
	{
		$query = $this->Petugas_model->deletePetugas($id);
		if($query){
			
			$this->M_global_model->ntf_swal('Informasi', 'Berhasil hapus data', 'success');
		} else {
			$this->M_global_model->ntf_swal('Informasi', 'Gagal hapus data', 'error');
		}
		redirect(base_url('petugas'));
	}

}

/* End of file Kelas.php and path \application\controllers\Kelas.php */
