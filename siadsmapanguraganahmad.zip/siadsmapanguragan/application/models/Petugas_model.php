<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
                        
class Petugas_model extends CI_Model 
{
    function ambildatapetugas()
    {
      $query = $this->db->get('tb_petugas');
      return $query->result();
    }
    
    function input_data_petugas($data)
      {
        return $this->db->insert('tb_petugas', $data);
      }

      function deletePetugas($id)
		{
			return $this->db->where('id', $id)->delete('tb_petugas');
         }
         
      function updateDataPetugas($id, $data) {
			return $this->db->where('id', $id)->update('tb_petugas', $data);
		}

        function getDataDetail($id) 
    {
			$this->db->where('id', $id);
			$query = $this->db->get('tb_petugas');
			return $query->row();
		}
                        
}


/* End of file Siswa_model.php and path \application\models\Siswa_model.php */
